# NOTES

How are we going to import the data into MongoDB???

## Possible leads

- The first thing we should try to do is import the data as it is in the csv
  files (i.e. without pre-processing it first). Check out the following link for
  more information:
  <https://medium.com/analytics-vidhya/import-csv-file-into-mongodb-9b9b86582f34>
